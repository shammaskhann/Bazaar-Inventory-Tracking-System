package com.example.bazaar.internshipproject.core.domain;

public enum StockType {
    STOCK_IN, SALE, REMOVAL
}
