package com.example.bazaar.internshipproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
