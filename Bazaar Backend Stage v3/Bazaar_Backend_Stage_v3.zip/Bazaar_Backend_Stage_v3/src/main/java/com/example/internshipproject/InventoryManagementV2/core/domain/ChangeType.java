package com.example.internshipproject.InventoryManagementV2.core.domain;

public enum ChangeType {
    STOCK_IN, SALE, MANUAL_REMOVAL
}
