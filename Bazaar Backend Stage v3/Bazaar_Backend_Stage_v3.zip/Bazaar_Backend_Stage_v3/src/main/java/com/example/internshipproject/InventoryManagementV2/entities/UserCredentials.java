package com.example.internshipproject.InventoryManagementV2.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserCredentials {
    String username;
    String password;
}
