package com.example.internshipproject.InventoryManagementV2.config;

//@Configuration
//public class JacksonConfig {
//    @Bean
//    public Module javaTimeModule() {
//        return new JavaTimeModule();
//    }
//
//    @Bean
//    public ObjectMapper objectMapper() {
//        return Jackson2ObjectMapperBuilder.json()
//                .modulesToInstall(new JavaTimeModule())
//                .build();
//    }
//}
